/**
 * craft-saas / server.js
 * Express — public landing + private admin panel + REST API
 *
 * DEMO MODE: boots automatically when JWT_SECRET is not configured.
 * Credentials for demo: demo / demo1234
 */
require('dotenv').config();

const express   = require('express');
const helmet    = require('helmet');
const cors      = require('cors');
const rateLimit = require('express-rate-limit');
const morgan    = require('morgan');
const path      = require('path');

// ── DEMO MODE ─────────────────────────────────────────────────
const DEMO_MODE = !process.env.JWT_SECRET ||
  process.env.JWT_SECRET.startsWith('REPLACE_WITH');

if (DEMO_MODE) {
  console.warn('\n⚠️  DEMO MODE — Set JWT_SECRET in .env for production.\n');
  process.env.JWT_SECRET = 'craft_demo_key_not_for_production_use_abcdef1234567890';
}

const app = express();

// ── SECURITY HEADERS ──────────────────────────────────────────
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc:  ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      styleSrc:   ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com", "https://fonts.gstatic.com"],
      fontSrc:    ["'self'", "https://fonts.gstatic.com"],
      imgSrc:     ["'self'", "data:"],
      connectSrc: ["'self'"]
    }
  }
}));

// ── CORS ──────────────────────────────────────────────────────
const origins = (process.env.ALLOWED_ORIGINS || 'http://localhost:3000')
  .split(',').map(s => s.trim());
app.use(cors({ origin: origins, credentials: true }));

// ── RATE LIMITING ─────────────────────────────────────────────
app.use('/api/', rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 15 * 60 * 1000,
  max:      parseInt(process.env.RATE_LIMIT_MAX)        || 200,
  message:  { error: 'Demasiadas solicitudes. Intenta más tarde.' },
  standardHeaders: true, legacyHeaders: false
}));

// ── BODY PARSING ──────────────────────────────────────────────
app.use(express.json({ limit: '100kb' }));
app.use(express.urlencoded({ extended: false }));

// ── LOGGING ───────────────────────────────────────────────────
app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));

// ── API ───────────────────────────────────────────────────────
app.use('/api/auth',     require('./api/routes/auth'));
app.use('/api/users',    require('./api/routes/users'));
app.use('/api/leads',    require('./api/routes/leads'));
app.use('/api/offers',   require('./api/routes/offers'));
app.use('/api/coupons',  require('./api/routes/coupons'));
app.use('/api/chatbot',  require('./api/routes/chatbot'));
app.use('/api/logs',     require('./api/routes/logs'));
app.use('/api/settings', require('./api/routes/settings'));

// ── ADMIN PANEL ───────────────────────────────────────────────
app.get('/admin',   (_, res) => res.sendFile(path.join(__dirname, 'admin', 'index.html')));
app.get('/admin/*', (_, res) => res.sendFile(path.join(__dirname, 'admin', 'index.html')));

// ── STATIC PUBLIC SITE ────────────────────────────────────────
app.use(express.static(path.join(__dirname), {
  index: false,
  dotfiles: 'deny'
}));
app.get('/', (_, res) => res.sendFile(path.join(__dirname, 'index.html')));

// ── API 404 ───────────────────────────────────────────────────
app.use('/api/*', (_, res) => res.status(404).json({ error: 'Endpoint no encontrado' }));

// ── ERROR HANDLER ─────────────────────────────────────────────
app.use((err, req, res, next) => { // eslint-disable-line
  console.error('[ERROR]', err.message);
  res.status(err.status || 500).json({
    error: process.env.NODE_ENV === 'production' ? 'Error interno' : err.message
  });
});

// ── START ─────────────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
app.listen(PORT, async () => {
  console.log(`\n🚀  Craft  →  http://localhost:${PORT}`);
  console.log(`    Admin  →  http://localhost:${PORT}/admin`);
  console.log(`    API    →  http://localhost:${PORT}/api`);
  if (DEMO_MODE) {
    console.log(`\n    🎭  DEMO  →  usuario: demo  |  contraseña: demo1234`);
    try { await require('./scripts/demo-seed')() } catch(e) { console.warn('demo-seed:', e.message) }
  }
  console.log();
});

module.exports = app;
